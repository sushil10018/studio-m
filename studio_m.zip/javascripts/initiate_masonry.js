var container = document.querySelector('.blog_list .container');
var msnry = new Masonry( container, {
	itemSelector: '.blog_each'
});

var msnry = new Masonry( '.blog_list .container', {
  // options
});